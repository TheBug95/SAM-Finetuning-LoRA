# cataract-seg > No Augmentation
https://universe.roboflow.com/muhammad-risma-nqgw8/cataract-seg

Provided by a Roboflow user
License: CC BY 4.0

